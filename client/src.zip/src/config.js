import { createGuestUser } from "./api/userApi"

window.SERVER_CONFIG = {
  ANDROID_URL: "http://10.0.2.2:3000",
  LOCAL_URL: "http://localhost:3000"
};

export async function initializeUserConfig() {
  let userId = sessionStorage.getItem("USER_ID");

  if (!userId) {
    userId = await createGuestUser();
    sessionStorage.setItem("USER_ID", userId);
  }

  window.USER_CONFIG = {
    USER_ID: userId,
  };
}
